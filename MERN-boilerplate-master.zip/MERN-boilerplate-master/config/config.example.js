// Copy this file as config.js in the same folder, with the proper database connection URI.

module.exports = {
  db: 'mongodb://username:password@url:port/db',
  db_dev: 'mongodb://url:port/db',
};
